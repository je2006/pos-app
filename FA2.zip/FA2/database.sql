CREATE DATABASE IF NOT EXISTS pos_db;
USE pos_db;

CREATE TABLE customers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  phone VARCHAR(20),
  created_at DATETIME NOT NULL
);

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  full_name VARCHAR(100) NOT NULL,
  created_at DATETIME NOT NULL
);

INSERT INTO customers (full_name, email, phone, created_at) VALUES
('Maria Santos', 'maria@example.com', '0917-123-4567', NOW()),
('Juan Dela Cruz', 'juan@example.com', '0918-234-5678', NOW()),
('Ana Reyes', 'ana@example.com', '0920-345-6789', NOW()),
('Carlo Mendoza', 'carlo@example.com', '0921-456-7890', NOW()),
('Liza Garcia', 'liza@example.com', '0922-567-8901', NOW());

INSERT INTO users (username, full_name, created_at) VALUES
('admin', 'System Administrator', NOW()),
('cashier1', 'Rosa Villanueva', NOW()),
('cashier2', 'Paolo Ramirez', NOW()),
('manager', 'Grace Bautista', NOW()),
('stockman', 'Dennis Castillo', NOW());