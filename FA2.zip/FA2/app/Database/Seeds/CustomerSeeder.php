<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class CustomerSeeder extends Seeder
{
    public function run()
    {
        $now = date('Y-m-d H:i:s');

        $rows = [
            ['full_name' => 'Maria Santos',    'email' => 'maria.santos@example.com',    'phone' => '09171234501', 'created_at' => $now],
            ['full_name' => 'Juan Dela Cruz',  'email' => 'juan.delacruz@example.com',   'phone' => '09171234502', 'created_at' => $now],
            ['full_name' => 'Ana Reyes',       'email' => 'ana.reyes@example.com',       'phone' => '09171234503', 'created_at' => $now],
            ['full_name' => 'Carlo Mendoza',   'email' => 'carlo.mendoza@example.com',   'phone' => '09171234504', 'created_at' => $now],
            ['full_name' => 'Liza Gonzales',   'email' => 'liza.gonzales@example.com',   'phone' => '09171234505', 'created_at' => $now],
        ];

        $this->db->table('customers')->insertBatch($rows);
    }
}