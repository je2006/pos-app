<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        $now = date('Y-m-d H:i:s');

        $rows = [
            ['username' => 'admin',    'full_name' => 'System Administrator', 'created_at' => $now],
            ['username' => 'cashier1', 'full_name' => 'Rosa Villanueva',      'created_at' => $now],
            ['username' => 'cashier2', 'full_name' => 'Mark Bautista',        'created_at' => $now],
            ['username' => 'manager',  'full_name' => 'Elena Ramos',          'created_at' => $now],
            ['username' => 'staff1',   'full_name' => 'Paolo Aquino',         'created_at' => $now],
        ];

        $this->db->table('users')->insertBatch($rows);
    }
}