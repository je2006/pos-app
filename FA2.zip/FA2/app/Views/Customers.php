<h1>Customer Accounts</h1>

<?php if (isset($customers) && !empty($customers)): ?>
    <table border="1" cellpadding="5">
        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Created</th>
        </tr>
        <?php foreach ($customers as $customer): ?>
            <tr>
                <td><?= esc($customer['id']) ?></td>
                <td><?= esc($customer['full_name']) ?></td>
                <td><?= esc($customer['email']) ?></td>
                <td>
                    <?php if (isset($customer['phone'])) { echo esc($customer['phone']); } else { echo '-'; } ?>
                </td>
                <td><?= esc($customer['created_at']) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
<?php else: ?>
    <p>No customers found.</p>
<?php endif; ?>