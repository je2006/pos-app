<h1><?= esc($title) ?></h1>
<table border="1" cellpadding="8">
    <tr><th>ID</th><th>Full Name</th><th>Email</th><th>Phone</th><th>Created At</th></tr>
    <?php foreach ($customers as $c): ?>
    <tr>
        <td><?= esc($c['id']) ?></td>
        <td><?= esc($c['full_name']) ?></td>
        <td><?= esc($c['email']) ?></td>
        <td><?= esc($c['phone']) ?></td>
        <td><?= esc($c['created_at']) ?></td>
    </tr>
    <?php endforeach; ?>
</table>